const { Client } = require('pg')
// const dotenv = require('dotenv');
// dotenv.config();
// const AWS = require('aws-sdk')
// const secretsManager = new AWS.SecretsManager({ region: 'us-east-1'  })

// const getSecrets = async (secretId) => {
//   return await new Promise((resolve, reject) => {
//     secretsManager.getSecretValue(secretId, (err, result) => {
//       if (err) reject(err)
//       // resolve(JSON.parse(result.secretString))
//       console.log(result)
//     })
//   })
// }

// const secret = getSecrets(process.env.SECRET_ID)

// const test = async () => {


exports.handler = async (event, context, cb) => {
  const client = new Client({
    user: 'postgres',
    host: process.env.HOST,
    // database: 'flashcards-2',
    password: process.env.PASSWORD,
    port: process.env.PORT,
  });

  await client
    .connect()
    .then(() => console.log('connected'))
    .catch(err => console.error('connection error', err.stack))

  client.query('SELECT * from public.flashcards', (err, res) => {
    if (err) throw err
    console.log(res.rows)
  })
  
  await client.end()
}